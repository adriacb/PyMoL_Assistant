import argparse
from fastapi import FastAPI
from typing import Optional, Union, List, Dict, Tuple

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--host", type=str, default="localhost")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    app = FastAPI(**vars(args))
    
    